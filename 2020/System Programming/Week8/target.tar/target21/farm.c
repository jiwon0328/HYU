/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_210(unsigned x)
{
    return x + 2425411699U;
}

unsigned getval_441()
{
    return 3351742792U;
}

void setval_269(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_184(unsigned x)
{
    return x + 2462550344U;
}

void setval_400(unsigned *p)
{
    *p = 3277343479U;
}

void setval_435(unsigned *p)
{
    *p = 2425378914U;
}

void setval_122(unsigned *p)
{
    *p = 2488834337U;
}

void setval_442(unsigned *p)
{
    *p = 3347662929U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_332()
{
    return 3281049225U;
}

unsigned addval_437(unsigned x)
{
    return x + 3375945225U;
}

unsigned getval_195()
{
    return 3229928137U;
}

unsigned addval_232(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_128(unsigned x)
{
    return x + 3373842825U;
}

unsigned addval_343(unsigned x)
{
    return x + 2430634313U;
}

unsigned addval_199(unsigned x)
{
    return x + 3380920777U;
}

unsigned addval_488(unsigned x)
{
    return x + 3534015113U;
}

unsigned addval_261(unsigned x)
{
    return x + 3685007753U;
}

void setval_234(unsigned *p)
{
    *p = 1355006344U;
}

unsigned addval_351(unsigned x)
{
    return x + 3380923033U;
}

unsigned getval_321()
{
    return 3527983497U;
}

unsigned getval_391()
{
    return 3252717896U;
}

unsigned getval_276()
{
    return 3536115337U;
}

unsigned getval_283()
{
    return 3380923017U;
}

void setval_461(unsigned *p)
{
    *p = 3353381192U;
}

void setval_155(unsigned *p)
{
    *p = 3284830675U;
}

unsigned addval_149(unsigned x)
{
    return x + 2496301357U;
}

unsigned getval_364()
{
    return 3227571849U;
}

unsigned getval_316()
{
    return 3674784137U;
}

unsigned addval_156(unsigned x)
{
    return x + 3286272328U;
}

void setval_482(unsigned *p)
{
    *p = 3267463447U;
}

unsigned addval_139(unsigned x)
{
    return x + 3674789545U;
}

void setval_342(unsigned *p)
{
    *p = 2497743176U;
}

void setval_349(unsigned *p)
{
    *p = 3224950409U;
}

unsigned addval_223(unsigned x)
{
    return x + 3251276182U;
}

void setval_144(unsigned *p)
{
    *p = 3286280520U;
}

unsigned addval_222(unsigned x)
{
    return x + 3676357001U;
}

unsigned getval_466()
{
    return 3376990857U;
}

void setval_496(unsigned *p)
{
    *p = 3286273352U;
}

void setval_107(unsigned *p)
{
    *p = 3531921049U;
}

void setval_251(unsigned *p)
{
    *p = 3676362409U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
